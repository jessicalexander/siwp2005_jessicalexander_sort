from src.sort.quick_sort import Quick

arr = [0, 50, 7, 34, 66, 85]
print('this is the unsorted list:')
print(arr)
result = Quick.quick_sort(arr)
print('this is the sorted list:')
print(result)

