from src.sort.insertion_sort import Insertion

arr = [0, 50, 7, 34, 66, 85]
print('this is the unsorted list:')
print(arr)
result = Insertion.insertion_sort(arr)
print('this is the sorted list:')
print(result)
